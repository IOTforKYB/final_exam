# 웹서버 프로그램 웹 브라우저에서 http://localhost:5000/로 접속하면 
# index.html을 실행하고 버튼을 이용하여 LED 작동시킴

from flask import Flask, request
from flask import render_template
import random

app = Flask(__name__)

@app.route("/")
def home():
    return render_template('index.html')

@app.route("/randomNumber")                       # index.html에서 이 주소를 접속하여 해당 함수를 실행
def randomNumber():
    try:
        num = random.randrange(1, 5000) # 1부터 5000 사이의 난수 생성
        num = str(num)
        return num                         # 함수가 'ok'문자열을 반환함
    except :
        return -1

if __name__ == "__main__":
    app.run(host="0.0.0.0")